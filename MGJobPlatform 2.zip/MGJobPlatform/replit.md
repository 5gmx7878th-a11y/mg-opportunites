# MGJobPlatform

## Overview

MGJobPlatform is a full-stack job marketplace application that connects job seekers with employers. The platform enables candidates to search and apply for jobs while allowing employers to post positions and manage applications. Built with a modern React frontend and Express backend, the application uses PostgreSQL for data persistence and implements Replit's OpenID Connect authentication.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Tooling**
- React 18 with TypeScript for type safety and component-based UI
- Vite as the build tool and development server for fast hot module replacement
- Wouter for client-side routing (lightweight alternative to React Router)
- TanStack Query (React Query) for server state management and data fetching

**UI Component System**
- shadcn/ui component library built on Radix UI primitives
- Tailwind CSS for utility-first styling with custom design tokens
- Design system inspired by LinkedIn and Indeed for professional appearance
- Inter font family for typography consistency
- Custom theme system with CSS variables for light/dark mode support

**State Management Strategy**
- TanStack Query handles all server state (users, jobs, applications, profiles)
- React hooks (useState, useEffect) for local component state
- Custom hooks pattern: `useAuth` for authentication state
- Form state managed by react-hook-form with Zod schema validation

### Backend Architecture

**Server Framework**
- Express.js for HTTP server and API routing
- TypeScript throughout the backend for type consistency
- RESTful API design pattern with resource-based endpoints

**Authentication & Session Management**
- Replit OpenID Connect (OIDC) integration via openid-client and Passport.js
- Session-based authentication using express-session
- PostgreSQL-backed session storage via connect-pg-simple
- Custom authentication middleware (`isAuthenticated`) to protect routes
- User type system: candidates vs employers with separate workflows

**Data Access Layer**
- Storage interface pattern (`IStorage`) abstracts database operations
- Drizzle ORM for type-safe SQL query building
- Schema-first approach with shared TypeScript types between client and server
- Zod schemas derived from Drizzle tables for runtime validation

**API Structure**
- `/api/auth/*` - Authentication endpoints (user info, setup)
- `/api/jobs/*` - Job CRUD operations with filtering
- `/api/applications/*` - Application management
- `/api/employer/*` - Employer-specific job listings
- `/api/profile/*` - Profile management for both user types

### Data Storage

**Database**
- PostgreSQL via Neon serverless driver with WebSocket support
- Connection pooling for efficient resource management
- Schema managed through Drizzle migrations

**Schema Design**
- `users` - Core user data with userType discriminator (candidate/employer)
- `sessions` - Server-side session storage for authentication
- `employerProfiles` - Extended profile data for employers (company info, website, location)
- `candidateProfiles` - Extended profile data for candidates (bio, skills, experience, resume)
- `jobs` - Job postings with status, type, location, salary, and requirements
- `applications` - Links candidates to jobs with cover letters and status tracking

**Data Relationships**
- One-to-one: User to EmployerProfile/CandidateProfile
- One-to-many: Employer to Jobs
- Many-to-many: Candidates to Jobs via Applications table

### External Dependencies

**Core Services**
- Neon PostgreSQL (serverless database hosting)
- Replit Authentication (OpenID Connect provider)

**Frontend Libraries**
- @tanstack/react-query: Server state management and caching
- wouter: Lightweight client-side routing
- react-hook-form: Form state and validation
- @hookform/resolvers: Zod integration for forms
- date-fns: Date formatting utilities
- All Radix UI primitives for accessible components

**Backend Libraries**
- drizzle-orm: Type-safe SQL query builder
- drizzle-kit: Schema migrations tool
- express-session: Session middleware
- connect-pg-simple: PostgreSQL session store
- passport: Authentication middleware
- openid-client: OIDC client implementation
- zod: Runtime schema validation
- drizzle-zod: Generate Zod schemas from Drizzle tables

**Build & Development Tools**
- Vite: Frontend bundler and dev server
- esbuild: Backend bundler for production
- tsx: TypeScript execution for development
- TypeScript: Type checking across the stack
- Tailwind CSS: Utility-first styling
- PostCSS with Autoprefixer: CSS processing

**Development Utilities**
- @replit/vite-plugin-runtime-error-modal: Error overlay in development
- @replit/vite-plugin-cartographer: Replit-specific tooling
- @replit/vite-plugin-dev-banner: Development environment banner