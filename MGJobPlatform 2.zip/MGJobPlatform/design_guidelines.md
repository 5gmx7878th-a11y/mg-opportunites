# MGJobPlatform Design Guidelines

## Design Approach

**Selected Approach**: Design System with Professional Job Platform References

Drawing inspiration from LinkedIn's professional polish and Indeed's clarity, combined with Material Design principles for information-dense applications. This ensures trustworthiness and efficiency for both employers and job seekers.

## Core Design Elements

### Typography System

**Font Families** (via Google Fonts):
- Primary: Inter (headings, UI elements, navigation)
- Secondary: System UI (body text, job descriptions)

**Type Scale**:
- Hero/Page Titles: text-4xl to text-5xl, font-bold
- Section Headers: text-2xl to text-3xl, font-semibold
- Card Titles/Job Titles: text-xl, font-semibold
- Body Text: text-base, font-normal
- Meta Info/Labels: text-sm, font-medium
- Small Labels/Timestamps: text-xs, font-normal

### Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, 12, and 16
- Component internal padding: p-4 to p-6
- Section spacing: py-12 to py-16
- Card gaps: gap-4 to gap-6
- Form field spacing: space-y-4

**Container Strategy**:
- Full-width sections: w-full with inner max-w-7xl mx-auto px-4
- Dashboard content: max-w-6xl
- Forms and focused content: max-w-2xl

## Page-Specific Layouts

### Landing Page (Public)

**Hero Section**:
- Height: 60-70vh on desktop, auto on mobile
- Layout: Two-column split (text left, image/illustration right)
- Hero image: Professional workspace or diverse team collaboration
- Primary CTA: "Post a Job" and "Find Jobs" buttons with backdrop-blur-md backgrounds
- Include trust indicators: "1000+ Companies Hiring" badge

**Structure** (6-7 sections):
1. Hero with dual CTAs
2. How It Works (3-column grid on desktop: For Employers / For Candidates / Success Stories)
3. Featured Jobs Preview (2-column grid showing 4-6 sample job cards)
4. Platform Benefits (2-column alternating layout with icons and descriptions)
5. Testimonials (3-column grid with employer and candidate testimonials, include profile photos)
6. Statistics Bar (4-column: Jobs Posted / Applications Sent / Companies / Success Rate)
7. Final CTA section with newsletter signup

### Job Listings Page

**Layout**: Sidebar + Main Content
- Left Sidebar (w-64 to w-80): Sticky filters panel
  - Search input at top
  - Filter sections: Job Type, Location, Salary Range, Experience Level, Posted Date
  - "Clear Filters" and "Apply Filters" buttons at bottom
  
- Main Content Area: 
  - Header bar with results count and sort dropdown
  - Job cards in single column (not grid - better for scanning)
  - Each card shows: Company logo (left), job title, company name, location, salary range (if available), job type badge, posted date, quick apply button
  - Pagination at bottom

### Job Detail Page

**Two-Column Layout**:
- Left Column (w-2/3): 
  - Company header with logo and name
  - Job title (text-3xl)
  - Meta row: Location, Job Type, Salary, Posted Date
  - Job description with proper text hierarchy
  - Requirements list
  - Benefits list
  
- Right Column (w-1/3, sticky):
  - Apply card with "Apply Now" CTA
  - Company info card
  - Share job buttons
  - "Save Job" option

### Employer Dashboard

**Layout**: Top Navigation + Sidebar + Content Area
- Sidebar (w-64): 
  - Dashboard, Posted Jobs, Applications Received, Messages, Company Profile, Post New Job

- Content Grid varies by section:
  - Dashboard: 4-column stats cards + Recent Applications table
  - Posted Jobs: Single column list of job cards with edit/delete actions
  - Applications: Table view with candidate info, status, and action buttons

### Candidate Dashboard

**Similar Structure**:
- Sidebar sections: Dashboard, Saved Jobs, My Applications, Messages, Profile
- Dashboard: 3-column stats + Application status overview
- Saved Jobs: 2-column grid of job cards
- Applications: Timeline view showing application progress

### Profile Pages

**Employer Profile**:
- Company header with cover image area and logo
- About section, Contact info, Active jobs preview

**Candidate Profile**:
- Professional header with profile photo placeholder
- Resume upload section
- Experience timeline
- Skills tags grid
- Education section

## Component Library

### Navigation
- Top navbar: Logo left, primary nav center, user menu/auth buttons right
- Height: h-16
- Sticky positioning on scroll

### Job Cards
- Padding: p-6
- Border with subtle shadow on hover
- Horizontal layout: Logo (w-16 h-16) | Content | CTA
- Include: Company name, job title, location icon + text, salary badge, job type badge, posted time

### Form Elements
- Input fields: h-12, rounded-lg borders
- Labels: text-sm, font-medium, mb-2
- Buttons: h-12, rounded-lg, font-semibold
- Form sections use space-y-6

### Badges/Tags
- Rounded-full for job types (Full-time, Part-time, Remote)
- Small size: px-3 py-1, text-sm
- Use consistently for categorization

### Data Tables
- Striped rows for better scanning
- Hover states on rows
- Action buttons right-aligned in last column

### Modal/Overlays
- Application modal: max-w-2xl, centered
- Include backdrop with backdrop-blur-sm

## Images

**Required Images**:
1. **Hero Image**: Professional office environment or diverse team collaboration - placed right side of hero, w-1/2 on desktop
2. **Company Logos**: Placeholder company logos (64x64px) for job cards and company profiles
3. **Testimonial Photos**: Professional headshots for testimonials section (96x96px, rounded-full)
4. **Profile Placeholders**: Avatar placeholders for candidate and employer profiles
5. **Empty States**: Illustrations for "no jobs found" or "no applications yet"

## Accessibility
- Maintain WCAG AA standards throughout
- Focus states visible on all interactive elements (ring-2 ring-offset-2)
- Proper label/input associations
- Skip links for navigation
- Semantic HTML structure

## Icons
Use **Heroicons** (outline style) via CDN for:
- Navigation icons (home, briefcase, inbox, user)
- Filter icons (funnel, search, location)
- Action icons (edit, trash, share, bookmark)
- Meta icons (clock, map-pin, currency)

## Responsive Behavior
- Mobile: Single column, collapsible filters, bottom navigation for dashboards
- Tablet: 2-column grids reduce to 1, sidebars become drawers
- Desktop: Full multi-column layouts with sticky sidebars

This creates a professional, efficient job platform that serves both employers and candidates with clarity and trustworthiness.