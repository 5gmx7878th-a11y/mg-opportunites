import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Jobs from "@/pages/Jobs";
import JobDetail from "@/pages/JobDetail";
import UserTypeSelection from "@/pages/UserTypeSelection";
import EmployerDashboard from "@/pages/EmployerDashboard";
import CandidateDashboard from "@/pages/CandidateDashboard";
import PostJob from "@/pages/PostJob";
import ProfileSetup from "@/pages/ProfileSetup";

function Router() {
  const { user, isLoading, isAuthenticated } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/jobs" component={Jobs} />
        <Route path="/jobs/:id" component={JobDetail} />
        <Route component={NotFound} />
      </Switch>
    );
  }

  if (!user?.userType) {
    return (
      <Switch>
        <Route path="/user-type" component={UserTypeSelection} />
        <Route>
          <Redirect to="/user-type" />
        </Route>
      </Switch>
    );
  }

  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/jobs" component={Jobs} />
      <Route path="/jobs/:id" component={JobDetail} />
      <Route path="/dashboard">
        {user.userType === "employer" ? <EmployerDashboard /> : <CandidateDashboard />}
      </Route>
      <Route path="/post-job" component={PostJob} />
      <Route path="/profile" component={ProfileSetup} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
