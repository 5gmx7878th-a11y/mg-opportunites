import { Button } from "@/components/ui/button";
import JobCard from "./JobCard";

export default function FeaturedJobs() {
  const jobs = [
    {
      id: "1",
      title: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      location: "Paris, France",
      salary: "60k - 80k €/year",
      type: "Full-time",
      postedTime: "2 days ago",
      description: "We're looking for an experienced frontend developer to join our growing team."
    },
    {
      id: "2",
      title: "Product Designer",
      company: "DesignHub",
      location: "Remote",
      salary: "50k - 70k €/year",
      type: "Remote",
      postedTime: "1 week ago",
      description: "Join our creative team to design beautiful user experiences."
    },
    {
      id: "3",
      title: "DevOps Engineer",
      company: "CloudSystems",
      location: "Lyon, France",
      salary: "55k - 75k €/year",
      type: "Full-time",
      postedTime: "3 days ago",
      description: "Help us build and maintain scalable cloud infrastructure."
    },
    {
      id: "4",
      title: "Marketing Manager",
      company: "GrowthCo",
      location: "Marseille, France",
      salary: "45k - 60k €/year",
      type: "Full-time",
      postedTime: "5 days ago",
      description: "Lead our marketing initiatives and drive brand awareness."
    }
  ];

  return (
    <section className="py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-2" data-testid="text-featured-title">
              Featured Jobs
            </h2>
            <p className="text-muted-foreground" data-testid="text-featured-description">
              Explore top opportunities from leading companies
            </p>
          </div>
          <Button variant="outline" data-testid="button-view-all">
            View All Jobs
          </Button>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {jobs.map((job) => (
            <JobCard key={job.id} {...job} />
          ))}
        </div>
      </div>
    </section>
  );
}
