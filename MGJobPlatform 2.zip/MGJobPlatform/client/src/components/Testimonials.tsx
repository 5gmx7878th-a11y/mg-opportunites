import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import testimonial1 from "@assets/generated_images/Testimonial_employer_headshot_8b313668.png";
import testimonial2 from "@assets/generated_images/Testimonial_candidate_headshot_e9dc3d84.png";
import testimonial3 from "@assets/generated_images/Testimonial_recruiter_headshot_2d613bec.png";

export default function Testimonials() {
  const testimonials = [
    {
      name: "Marie Dubois",
      role: "HR Director",
      company: "TechCorp Inc.",
      avatar: testimonial1,
      content: "MGJobPlatform helped us find incredible talent quickly. The quality of candidates is outstanding, and the platform is so easy to use."
    },
    {
      name: "Thomas Laurent",
      role: "Software Engineer",
      company: "Hired at DesignHub",
      avatar: testimonial2,
      content: "I found my dream job within two weeks! The search filters made it easy to find positions that matched my skills perfectly."
    },
    {
      name: "Sophie Martin",
      role: "Recruitment Lead",
      company: "GrowthCo",
      avatar: testimonial3,
      content: "The best hiring platform we've used. It streamlined our entire recruitment process and saved us countless hours."
    }
  ];

  return (
    <section className="py-16 md:py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-testimonials-title">
            What Our Users Say
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-testimonials-description">
            Join thousands of satisfied employers and job seekers
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="hover-elevate" data-testid={`card-testimonial-${index}`}>
              <CardContent className="pt-6">
                <div className="flex items-center gap-4 mb-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                    <AvatarFallback>{testimonial.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-semibold" data-testid={`text-name-${index}`}>{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground" data-testid={`text-role-${index}`}>
                      {testimonial.role}
                    </div>
                    <div className="text-xs text-muted-foreground" data-testid={`text-company-${index}`}>
                      {testimonial.company}
                    </div>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground" data-testid={`text-content-${index}`}>
                  "{testimonial.content}"
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
