import JobCard from '../JobCard';

export default function JobCardExample() {
  return (
    <div className="space-y-4 p-4">
      <JobCard
        id="1"
        title="Senior Frontend Developer"
        company="TechCorp Inc."
        location="Paris, France"
        salary="60k - 80k €/year"
        type="Full-time"
        postedTime="2 days ago"
        description="We're looking for an experienced frontend developer to join our growing team. You'll work on cutting-edge web applications using React and TypeScript."
      />
      <JobCard
        id="2"
        title="Product Designer"
        company="DesignHub"
        location="Remote"
        salary="50k - 70k €/year"
        type="Remote"
        postedTime="1 week ago"
        description="Join our creative team to design beautiful and intuitive user experiences for our SaaS products."
      />
    </div>
  );
}
