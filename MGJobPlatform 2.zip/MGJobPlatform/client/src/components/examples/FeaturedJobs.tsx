import FeaturedJobs from '../FeaturedJobs';

export default function FeaturedJobsExample() {
  return <FeaturedJobs />;
}
