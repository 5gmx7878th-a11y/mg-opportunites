import { Link } from "wouter";
import { Briefcase } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function Footer() {
  return (
    <footer className="bg-muted/30 border-t">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Briefcase className="h-6 w-6 text-primary" />
              <span className="font-bold text-lg">MGJobPlatform</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Connecting talented professionals with opportunities worldwide.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4" data-testid="text-for-candidates-footer">For Candidates</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/jobs" className="text-muted-foreground hover-elevate active-elevate-2 px-2 py-1 -ml-2 inline-block rounded-md" data-testid="link-browse-jobs">
                  Browse Jobs
                </Link>
              </li>
              <li>
                <Link href="/saved" className="text-muted-foreground hover-elevate active-elevate-2 px-2 py-1 -ml-2 inline-block rounded-md" data-testid="link-saved-jobs">
                  Saved Jobs
                </Link>
              </li>
              <li>
                <Link href="/applications" className="text-muted-foreground hover-elevate active-elevate-2 px-2 py-1 -ml-2 inline-block rounded-md" data-testid="link-applications">
                  My Applications
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4" data-testid="text-for-employers-footer">For Employers</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/post-job" className="text-muted-foreground hover-elevate active-elevate-2 px-2 py-1 -ml-2 inline-block rounded-md" data-testid="link-post-job">
                  Post a Job
                </Link>
              </li>
              <li>
                <Link href="/dashboard" className="text-muted-foreground hover-elevate active-elevate-2 px-2 py-1 -ml-2 inline-block rounded-md" data-testid="link-dashboard">
                  Dashboard
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="text-muted-foreground hover-elevate active-elevate-2 px-2 py-1 -ml-2 inline-block rounded-md" data-testid="link-pricing">
                  Pricing
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4" data-testid="text-newsletter">Newsletter</h3>
            <p className="text-sm text-muted-foreground mb-3">
              Get the latest job opportunities delivered to your inbox.
            </p>
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder="Enter your email"
                className="text-sm"
                data-testid="input-newsletter"
              />
              <Button size="sm" data-testid="button-subscribe">
                Subscribe
              </Button>
            </div>
          </div>
        </div>

        <div className="border-t pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
          <p data-testid="text-copyright">
            © 2024 MGJobPlatform. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link href="/privacy" className="hover-elevate active-elevate-2 px-2 py-1 rounded-md" data-testid="link-privacy">
              Privacy Policy
            </Link>
            <Link href="/terms" className="hover-elevate active-elevate-2 px-2 py-1 rounded-md" data-testid="link-terms">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
