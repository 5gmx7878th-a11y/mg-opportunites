import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import heroImage from "@assets/generated_images/Hero_team_collaboration_image_00590da4.png";

export default function HeroSection() {
  return (
    <section className="relative min-h-[70vh] flex items-center">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/95 to-background/70 z-10" />
        <img
          src={heroImage}
          alt="Professional team collaboration"
          className="w-full h-full object-cover"
        />
      </div>

      <div className="relative z-20 max-w-7xl mx-auto px-4 py-16 md:py-24 w-full">
        <div className="max-w-2xl">
          <Badge className="mb-4" data-testid="badge-trust">
            Trusted by 1000+ Companies
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-6" data-testid="text-hero-title">
            Find Your Dream Job or Hire Top Talent
          </h1>
          <p className="text-lg text-muted-foreground mb-8" data-testid="text-hero-description">
            Connect with opportunities that match your skills and ambitions. Whether you're seeking your next career move or looking to build your team, we've got you covered.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Search jobs, companies, or keywords..."
                className="pl-10 h-12"
                data-testid="input-hero-search"
              />
            </div>
            <Button size="lg" className="h-12" data-testid="button-hero-search">
              Search Jobs
            </Button>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button asChild data-testid="button-post-job">
              <a href="/employers">Post a Job</a>
            </Button>
            <Button variant="outline" className="backdrop-blur-md bg-background/50" asChild data-testid="button-find-jobs">
              <a href="/jobs">Browse All Jobs</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
