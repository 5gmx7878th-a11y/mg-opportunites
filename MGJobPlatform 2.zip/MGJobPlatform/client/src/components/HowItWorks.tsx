import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UserPlus, Search, Send, Briefcase, Users, CheckCircle } from "lucide-react";

export default function HowItWorks() {
  const forEmployers = [
    {
      icon: UserPlus,
      title: "Create Account",
      description: "Sign up and set up your company profile in minutes"
    },
    {
      icon: Briefcase,
      title: "Post Jobs",
      description: "Create detailed job listings with your requirements"
    },
    {
      icon: Users,
      title: "Review Candidates",
      description: "Browse applications and connect with top talent"
    }
  ];

  const forCandidates = [
    {
      icon: UserPlus,
      title: "Build Profile",
      description: "Create your professional profile and showcase your skills"
    },
    {
      icon: Search,
      title: "Find Opportunities",
      description: "Search and filter jobs that match your career goals"
    },
    {
      icon: Send,
      title: "Apply Easily",
      description: "Submit applications with one click and track your progress"
    }
  ];

  const successStories = [
    {
      icon: CheckCircle,
      stat: "10,000+",
      label: "Jobs Posted"
    },
    {
      icon: Users,
      stat: "50,000+",
      label: "Active Candidates"
    },
    {
      icon: Briefcase,
      stat: "1,000+",
      label: "Companies Hiring"
    }
  ];

  return (
    <section className="py-16 md:py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-how-title">
            How It Works
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-how-description">
            Simple, fast, and effective. Start your journey in three easy steps.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div>
            <h3 className="text-xl font-semibold mb-6 text-center" data-testid="text-for-employers">For Employers</h3>
            <div className="space-y-4">
              {forEmployers.map((item, index) => (
                <Card key={index} className="hover-elevate" data-testid={`card-employer-${index}`}>
                  <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
                    <div className="p-2 bg-primary/10 rounded-md">
                      <item.icon className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle className="text-base">{item.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-6 text-center" data-testid="text-for-candidates">For Candidates</h3>
            <div className="space-y-4">
              {forCandidates.map((item, index) => (
                <Card key={index} className="hover-elevate" data-testid={`card-candidate-${index}`}>
                  <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
                    <div className="p-2 bg-primary/10 rounded-md">
                      <item.icon className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle className="text-base">{item.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-6 text-center" data-testid="text-success-stories">Success Stories</h3>
            <div className="space-y-4">
              {successStories.map((item, index) => (
                <Card key={index} className="hover-elevate" data-testid={`card-success-${index}`}>
                  <CardContent className="pt-6 flex flex-col items-center text-center">
                    <item.icon className="h-8 w-8 text-primary mb-3" />
                    <div className="text-3xl font-bold mb-1">{item.stat}</div>
                    <p className="text-sm text-muted-foreground">{item.label}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
