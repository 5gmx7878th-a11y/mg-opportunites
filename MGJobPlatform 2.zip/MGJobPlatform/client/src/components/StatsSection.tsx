import { Card, CardContent } from "@/components/ui/card";
import { Briefcase, Users, Building2, TrendingUp } from "lucide-react";

export default function StatsSection() {
  const stats = [
    {
      icon: Briefcase,
      value: "10,000+",
      label: "Jobs Posted",
      description: "Active opportunities"
    },
    {
      icon: Users,
      value: "50,000+",
      label: "Candidates",
      description: "Talented professionals"
    },
    {
      icon: Building2,
      value: "1,000+",
      label: "Companies",
      description: "Leading employers"
    },
    {
      icon: TrendingUp,
      value: "95%",
      label: "Success Rate",
      description: "Positions filled"
    }
  ];

  return (
    <section className="py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <Card key={index} className="hover-elevate" data-testid={`card-stat-${index}`}>
              <CardContent className="pt-6 text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg mb-3">
                  <stat.icon className="h-6 w-6 text-primary" />
                </div>
                <div className="text-3xl font-bold mb-1" data-testid={`text-value-${index}`}>
                  {stat.value}
                </div>
                <div className="font-semibold mb-1" data-testid={`text-label-${index}`}>
                  {stat.label}
                </div>
                <p className="text-xs text-muted-foreground" data-testid={`text-description-${index}`}>
                  {stat.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
