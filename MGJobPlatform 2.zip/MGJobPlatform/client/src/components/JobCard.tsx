import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Clock, DollarSign } from "lucide-react";
import companyLogo from "@assets/generated_images/Company_logo_placeholder_5385e4d6.png";

interface JobCardProps {
  id: string;
  title: string;
  company: string;
  location: string;
  salary?: string;
  type: string;
  postedTime: string;
  description?: string;
}

export default function JobCard({
  id,
  title,
  company,
  location,
  salary,
  type,
  postedTime,
  description
}: JobCardProps) {
  return (
    <Card className="hover-elevate" data-testid={`card-job-${id}`}>
      <CardHeader className="flex flex-row items-start gap-4 space-y-0 pb-4">
        <img
          src={companyLogo}
          alt={`${company} logo`}
          className="w-16 h-16 rounded-md object-cover flex-shrink-0"
          data-testid={`img-company-logo-${id}`}
        />
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-lg mb-1" data-testid={`text-job-title-${id}`}>
            {title}
          </h3>
          <p className="text-sm text-muted-foreground mb-2" data-testid={`text-company-${id}`}>
            {company}
          </p>
          <div className="flex flex-wrap gap-2 items-center text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <MapPin className="h-4 w-4" />
              <span data-testid={`text-location-${id}`}>{location}</span>
            </div>
            {salary && (
              <div className="flex items-center gap-1">
                <DollarSign className="h-4 w-4" />
                <span data-testid={`text-salary-${id}`}>{salary}</span>
              </div>
            )}
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              <span data-testid={`text-posted-${id}`}>{postedTime}</span>
            </div>
          </div>
        </div>
        <div className="flex flex-col gap-2 items-end">
          <Badge data-testid={`badge-type-${id}`}>{type}</Badge>
          <Button size="sm" data-testid={`button-apply-${id}`}>
            Apply Now
          </Button>
        </div>
      </CardHeader>
      {description && (
        <CardContent className="pt-0">
          <p className="text-sm text-muted-foreground line-clamp-2" data-testid={`text-description-${id}`}>
            {description}
          </p>
        </CardContent>
      )}
    </Card>
  );
}
