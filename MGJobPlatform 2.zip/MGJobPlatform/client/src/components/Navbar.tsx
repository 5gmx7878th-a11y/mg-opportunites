import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Briefcase, Menu, X, LogOut, User } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, isAuthenticated, isLoading } = useAuth();

  return (
    <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex h-16 items-center justify-between gap-4">
          <Link href="/" className="flex items-center gap-2 hover-elevate active-elevate-2 px-2 py-1 rounded-md">
            <Briefcase className="h-6 w-6 text-primary" data-testid="icon-logo" />
            <span className="font-bold text-xl" data-testid="text-brand">MGJobPlatform</span>
          </Link>

          <div className="hidden md:flex items-center gap-6">
            <Link href="/jobs" className="text-sm font-medium hover-elevate active-elevate-2 px-3 py-2 rounded-md" data-testid="link-jobs">
              Find Jobs
            </Link>
            {isAuthenticated && user?.userType && (
              <Link href="/dashboard" className="text-sm font-medium hover-elevate active-elevate-2 px-3 py-2 rounded-md" data-testid="link-dashboard">
                Dashboard
              </Link>
            )}
          </div>

          <div className="hidden md:flex items-center gap-2">
            {isLoading ? (
              <div className="w-20 h-9 bg-muted animate-pulse rounded-md" />
            ) : isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-2 hover-elevate active-elevate-2 px-2 py-1 rounded-md" data-testid="button-user-menu">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user?.profileImageUrl || ""} alt={user?.firstName || "User"} />
                      <AvatarFallback>
                        {user?.firstName?.[0]}{user?.lastName?.[0]}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-medium">
                      {user?.firstName || "User"}
                    </span>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild>
                    <Link href="/profile" className="cursor-pointer" data-testid="link-profile">
                      <User className="h-4 w-4 mr-2" />
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <a href="/api/logout" className="cursor-pointer" data-testid="link-logout">
                      <LogOut className="h-4 w-4 mr-2" />
                      Log Out
                    </a>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <Button variant="ghost" asChild data-testid="button-login">
                  <a href="/api/login">Sign In</a>
                </Button>
                <Button asChild data-testid="button-signup">
                  <a href="/api/login">Get Started</a>
                </Button>
              </>
            )}
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="button-menu-toggle"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-2 border-t">
            <Link href="/jobs" className="block px-3 py-2 text-sm font-medium hover-elevate active-elevate-2 rounded-md" data-testid="link-jobs-mobile">
              Find Jobs
            </Link>
            {isAuthenticated && user?.userType && (
              <Link href="/dashboard" className="block px-3 py-2 text-sm font-medium hover-elevate active-elevate-2 rounded-md" data-testid="link-dashboard-mobile">
                Dashboard
              </Link>
            )}
            <div className="pt-2 space-y-2">
              {isAuthenticated ? (
                <>
                  <Link href="/profile">
                    <Button variant="ghost" className="w-full" data-testid="button-profile-mobile">
                      <User className="h-4 w-4 mr-2" />
                      Profile
                    </Button>
                  </Link>
                  <a href="/api/logout">
                    <Button variant="ghost" className="w-full" data-testid="button-logout-mobile">
                      <LogOut className="h-4 w-4 mr-2" />
                      Log Out
                    </Button>
                  </a>
                </>
              ) : (
                <>
                  <a href="/api/login">
                    <Button variant="ghost" className="w-full" data-testid="button-login-mobile">
                      Sign In
                    </Button>
                  </a>
                  <a href="/api/login">
                    <Button className="w-full" data-testid="button-signup-mobile">
                      Get Started
                    </Button>
                  </a>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
