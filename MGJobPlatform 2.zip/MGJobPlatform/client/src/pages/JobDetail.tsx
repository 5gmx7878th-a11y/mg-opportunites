import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { MapPin, DollarSign, Briefcase, Building2, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useState } from "react";
import companyLogo from "@assets/generated_images/Company_logo_placeholder_5385e4d6.png";

export default function JobDetail() {
  const params = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const [coverLetter, setCoverLetter] = useState("");

  const { data: jobData, isLoading } = useQuery<any>({
    queryKey: ["/api/jobs", params.id],
    enabled: !!params.id,
  });

  const applyMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("/api/applications", "POST", {
        jobId: params.id,
        coverLetter,
      });
    },
    onSuccess: () => {
      toast({
        title: "Application Submitted",
        description: "Your application has been sent to the employer.",
      });
      setCoverLetter("");
      queryClient.invalidateQueries({ queryKey: ["/api/applications/candidate"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  if (isLoading || authLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1 flex items-center justify-center">
          <p className="text-muted-foreground">Loading...</p>
        </main>
        <Footer />
      </div>
    );
  }

  if (!jobData) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1 flex items-center justify-center">
          <Card>
            <CardContent className="pt-6">
              <p className="text-muted-foreground">Job not found</p>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  const isCandidate = user?.userType === "candidate";

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <Button 
            variant="ghost" 
            onClick={() => navigate("/jobs")}
            className="mb-6"
            data-testid="button-back"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Jobs
          </Button>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-start gap-4 mb-4">
                    <img
                      src={companyLogo}
                      alt="Company logo"
                      className="w-20 h-20 rounded-md object-cover"
                      data-testid="img-company-logo"
                    />
                    <div className="flex-1">
                      <h1 className="text-3xl font-bold mb-2" data-testid="text-job-title">
                        {jobData.title}
                      </h1>
                      <div className="flex items-center gap-2 text-muted-foreground mb-2">
                        <Building2 className="h-4 w-4" />
                        <span data-testid="text-company-name">
                          {jobData.employerProfile?.companyName || "Company"}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          <span data-testid="text-location">{jobData.location}</span>
                        </div>
                        {jobData.salary && (
                          <div className="flex items-center gap-1">
                            <DollarSign className="h-4 w-4" />
                            <span data-testid="text-salary">{jobData.salary}</span>
                          </div>
                        )}
                        <div className="flex items-center gap-1">
                          <Briefcase className="h-4 w-4" />
                          <Badge data-testid="badge-job-type">{jobData.jobType}</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h2 className="text-xl font-semibold mb-3" data-testid="text-description-title">
                      Job Description
                    </h2>
                    <p className="text-muted-foreground whitespace-pre-wrap" data-testid="text-description">
                      {jobData.description}
                    </p>
                  </div>

                  {jobData.requirements && (
                    <div>
                      <h2 className="text-xl font-semibold mb-3" data-testid="text-requirements-title">
                        Requirements
                      </h2>
                      <p className="text-muted-foreground whitespace-pre-wrap" data-testid="text-requirements">
                        {jobData.requirements}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <div>
              {isCandidate ? (
                <Card className="sticky top-4">
                  <CardHeader>
                    <CardTitle data-testid="text-apply-title">Apply for this Position</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">
                        Cover Letter (Optional)
                      </label>
                      <Textarea
                        placeholder="Tell the employer why you're a great fit..."
                        rows={6}
                        value={coverLetter}
                        onChange={(e) => setCoverLetter(e.target.value)}
                        data-testid="textarea-cover-letter"
                      />
                    </div>
                    <Button
                      className="w-full"
                      onClick={() => applyMutation.mutate()}
                      disabled={applyMutation.isPending}
                      data-testid="button-apply"
                    >
                      {applyMutation.isPending ? "Submitting..." : "Submit Application"}
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <Card className="sticky top-4">
                  <CardContent className="pt-6">
                    <p className="text-sm text-muted-foreground text-center">
                      Only candidates can apply for jobs.
                    </p>
                  </CardContent>
                </Card>
              )}

              {jobData.employerProfile && (
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle data-testid="text-about-company">About the Company</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <p className="font-semibold mb-1" data-testid="text-employer-company">
                        {jobData.employerProfile.companyName}
                      </p>
                      {jobData.employerProfile.companyDescription && (
                        <p className="text-sm text-muted-foreground" data-testid="text-employer-description">
                          {jobData.employerProfile.companyDescription}
                        </p>
                      )}
                    </div>
                    {jobData.employerProfile.website && (
                      <div>
                        <p className="text-sm text-muted-foreground">Website</p>
                        <a
                          href={jobData.employerProfile.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm text-primary hover:underline"
                          data-testid="link-website"
                        >
                          {jobData.employerProfile.website}
                        </a>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
