import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Briefcase, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Eye,
  MapPin,
  DollarSign
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";

export default function CandidateDashboard() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();

  const { data: applications = [], isLoading: appsLoading } = useQuery<any[]>({
    queryKey: ["/api/applications/candidate"],
    enabled: isAuthenticated && user?.userType === "candidate",
  });

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    } else if (!authLoading && user?.userType !== "candidate") {
      toast({
        title: "Access Denied",
        description: "Only candidates can access this page.",
        variant: "destructive",
      });
      navigate("/");
    }
  }, [isAuthenticated, authLoading, user, toast, navigate]);

  if (authLoading || appsLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1 flex items-center justify-center">
          <p className="text-muted-foreground">Loading...</p>
        </main>
        <Footer />
      </div>
    );
  }

  const pendingApps = applications.filter(app => app.status === "pending");
  const reviewedApps = applications.filter(app => app.status === "reviewed");
  const acceptedApps = applications.filter(app => app.status === "accepted");
  const rejectedApps = applications.filter(app => app.status === "rejected");

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />;
      case "reviewed":
        return <Eye className="h-4 w-4" />;
      case "accepted":
        return <CheckCircle className="h-4 w-4" />;
      case "rejected":
        return <XCircle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusVariant = (status: string): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case "accepted":
        return "default";
      case "reviewed":
        return "secondary";
      case "rejected":
        return "destructive";
      default:
        return "outline";
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
            <div>
              <h1 className="text-4xl font-bold mb-2" data-testid="text-page-title">
                Candidate Dashboard
              </h1>
              <p className="text-muted-foreground" data-testid="text-page-description">
                Track your job applications
              </p>
            </div>
            <Button 
              onClick={() => navigate("/jobs")}
              data-testid="button-browse-jobs"
            >
              <Briefcase className="h-4 w-4 mr-2" />
              Browse Jobs
            </Button>
          </div>

          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-1 pb-2">
                <CardTitle className="text-sm font-medium">Pending</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-pending-count">
                  {pendingApps.length}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-1 pb-2">
                <CardTitle className="text-sm font-medium">Reviewed</CardTitle>
                <Eye className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-reviewed-count">
                  {reviewedApps.length}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-1 pb-2">
                <CardTitle className="text-sm font-medium">Accepted</CardTitle>
                <CheckCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-accepted-count">
                  {acceptedApps.length}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-1 pb-2">
                <CardTitle className="text-sm font-medium">Rejected</CardTitle>
                <XCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-rejected-count">
                  {rejectedApps.length}
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-4" data-testid="text-applications">
              Your Applications
            </h2>
            {applications.length === 0 ? (
              <Card>
                <CardContent className="pt-12 pb-12 text-center">
                  <Briefcase className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No applications yet</h3>
                  <p className="text-muted-foreground mb-6">
                    Start applying to jobs to see them here
                  </p>
                  <Button onClick={() => navigate("/jobs")} data-testid="button-browse-jobs-empty">
                    <Briefcase className="h-4 w-4 mr-2" />
                    Browse Jobs
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {applications.map((application) => (
                  <Card key={application.id} data-testid={`card-application-${application.id}`}>
                    <CardContent className="pt-6">
                      <div className="flex flex-col md:flex-row gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold text-lg" data-testid={`text-job-title-${application.id}`}>
                              {application.job?.title || "Unknown Job"}
                            </h3>
                            <Badge 
                              variant={getStatusVariant(application.status)}
                              data-testid={`badge-status-${application.id}`}
                            >
                              <span className="mr-1">{getStatusIcon(application.status)}</span>
                              {application.status}
                            </Badge>
                          </div>
                          {application.job && (
                            <>
                              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                                <span data-testid={`text-company-${application.id}`}>
                                  {application.employerProfile?.companyName || "Company"}
                                </span>
                              </div>
                              <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-2">
                                <div className="flex items-center gap-1">
                                  <MapPin className="h-4 w-4" />
                                  <span data-testid={`text-location-${application.id}`}>
                                    {application.job.location}
                                  </span>
                                </div>
                                {application.job.salary && (
                                  <div className="flex items-center gap-1">
                                    <DollarSign className="h-4 w-4" />
                                    <span data-testid={`text-salary-${application.id}`}>
                                      {application.job.salary}
                                    </span>
                                  </div>
                                )}
                                <Badge data-testid={`badge-type-${application.id}`}>
                                  {application.job.jobType}
                                </Badge>
                              </div>
                            </>
                          )}
                          <p className="text-xs text-muted-foreground" data-testid={`text-applied-date-${application.id}`}>
                            Applied {new Date(application.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex md:flex-col gap-2">
                          {application.job && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => navigate(`/jobs/${application.job.id}`)}
                              data-testid={`button-view-${application.id}`}
                            >
                              <Eye className="h-4 w-4 mr-2" />
                              View Job
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
