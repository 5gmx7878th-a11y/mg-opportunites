import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertEmployerProfileSchema, insertCandidateProfileSchema } from "@shared/schema";
import { z } from "zod";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

const employerFormSchema = insertEmployerProfileSchema.omit({ userId: true });
const candidateFormSchema = insertCandidateProfileSchema.omit({ userId: true });

type EmployerFormValues = z.infer<typeof employerFormSchema>;
type CandidateFormValues = z.infer<typeof candidateFormSchema>;

export default function ProfileSetup() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const [skillInput, setSkillInput] = useState("");

  const isEmployer = user?.userType === "employer";
  const isCandidate = user?.userType === "candidate";

  const employerForm = useForm<EmployerFormValues>({
    resolver: zodResolver(employerFormSchema),
    defaultValues: {
      companyName: "",
      companyDescription: "",
      website: "",
      location: "",
    },
  });

  const candidateForm = useForm<CandidateFormValues>({
    resolver: zodResolver(candidateFormSchema),
    defaultValues: {
      title: "",
      bio: "",
      skills: [],
      experience: "",
      education: "",
      resumeUrl: "",
    },
  });

  useEffect(() => {
    if (user?.profile) {
      if (isEmployer) {
        employerForm.reset({
          companyName: user.profile.companyName || "",
          companyDescription: user.profile.companyDescription || "",
          website: user.profile.website || "",
          location: user.profile.location || "",
        });
      } else if (isCandidate) {
        candidateForm.reset({
          title: user.profile.title || "",
          bio: user.profile.bio || "",
          skills: user.profile.skills || [],
          experience: user.profile.experience || "",
          education: user.profile.education || "",
          resumeUrl: user.profile.resumeUrl || "",
        });
      }
    }
  }, [user, isEmployer, isCandidate, employerForm, candidateForm]);

  const employerMutation = useMutation({
    mutationFn: async (data: EmployerFormValues) => {
      if (user?.profile) {
        return await apiRequest("/api/employer/profile", "PUT", data);
      }
      return await apiRequest("/api/employer/profile", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Profile saved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      navigate("/dashboard");
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const candidateMutation = useMutation({
    mutationFn: async (data: CandidateFormValues) => {
      if (user?.profile) {
        return await apiRequest("/api/candidate/profile", "PUT", data);
      }
      return await apiRequest("/api/candidate/profile", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Profile saved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      navigate("/dashboard");
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  if (authLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1 flex items-center justify-center">
          <p className="text-muted-foreground">Loading...</p>
        </main>
        <Footer />
      </div>
    );
  }

  const onEmployerSubmit = (data: EmployerFormValues) => {
    employerMutation.mutate(data);
  };

  const onCandidateSubmit = (data: CandidateFormValues) => {
    candidateMutation.mutate(data);
  };

  const addSkill = () => {
    if (!skillInput.trim()) return;
    const currentSkills = candidateForm.getValues("skills") || [];
    if (!currentSkills.includes(skillInput.trim())) {
      candidateForm.setValue("skills", [...currentSkills, skillInput.trim()]);
      setSkillInput("");
    }
  };

  const removeSkill = (skillToRemove: string) => {
    const currentSkills = candidateForm.getValues("skills") || [];
    candidateForm.setValue(
      "skills",
      currentSkills.filter(skill => skill !== skillToRemove)
    );
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <div className="max-w-2xl mx-auto px-4 py-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-3xl" data-testid="text-page-title">
                {user?.profile ? "Edit Profile" : "Complete Your Profile"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isEmployer && (
                <Form {...employerForm}>
                  <form onSubmit={employerForm.handleSubmit(onEmployerSubmit)} className="space-y-6">
                    <FormField
                      control={employerForm.control}
                      name="companyName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Name</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="e.g. Acme Corporation" 
                              {...field} 
                              data-testid="input-company-name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={employerForm.control}
                      name="companyDescription"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Description (Optional)</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell candidates about your company..."
                              rows={4}
                              {...field}
                              value={field.value || ""}
                              data-testid="textarea-company-description"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={employerForm.control}
                      name="website"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Website (Optional)</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="https://www.example.com" 
                              {...field}
                              value={field.value || ""}
                              data-testid="input-website"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={employerForm.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location (Optional)</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="e.g. San Francisco, CA" 
                              {...field}
                              value={field.value || ""}
                              data-testid="input-location"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex gap-4">
                      <Button
                        type="submit"
                        disabled={employerMutation.isPending}
                        className="flex-1"
                        data-testid="button-submit"
                      >
                        {employerMutation.isPending ? "Saving..." : "Save Profile"}
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => navigate("/dashboard")}
                        data-testid="button-cancel"
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                </Form>
              )}

              {isCandidate && (
                <Form {...candidateForm}>
                  <form onSubmit={candidateForm.handleSubmit(onCandidateSubmit)} className="space-y-6">
                    <FormField
                      control={candidateForm.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Professional Title (Optional)</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="e.g. Senior Software Engineer" 
                              {...field}
                              value={field.value || ""}
                              data-testid="input-title"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={candidateForm.control}
                      name="bio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bio (Optional)</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell employers about yourself..."
                              rows={4}
                              {...field}
                              value={field.value || ""}
                              data-testid="textarea-bio"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={candidateForm.control}
                      name="skills"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Skills (Optional)</FormLabel>
                          <div className="space-y-2">
                            <div className="flex gap-2">
                              <Input
                                placeholder="Add a skill..."
                                value={skillInput}
                                onChange={(e) => setSkillInput(e.target.value)}
                                onKeyPress={(e) => {
                                  if (e.key === "Enter") {
                                    e.preventDefault();
                                    addSkill();
                                  }
                                }}
                                data-testid="input-skill"
                              />
                              <Button
                                type="button"
                                variant="outline"
                                onClick={addSkill}
                                data-testid="button-add-skill"
                              >
                                Add
                              </Button>
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {(field.value || []).map((skill) => (
                                <Badge key={skill} variant="secondary" data-testid={`badge-skill-${skill}`}>
                                  {skill}
                                  <button
                                    type="button"
                                    onClick={() => removeSkill(skill)}
                                    className="ml-2"
                                    data-testid={`button-remove-skill-${skill}`}
                                  >
                                    <X className="h-3 w-3" />
                                  </button>
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={candidateForm.control}
                      name="experience"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Experience (Optional)</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe your work experience..."
                              rows={4}
                              {...field}
                              value={field.value || ""}
                              data-testid="textarea-experience"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={candidateForm.control}
                      name="education"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Education (Optional)</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="List your educational background..."
                              rows={3}
                              {...field}
                              value={field.value || ""}
                              data-testid="textarea-education"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex gap-4">
                      <Button
                        type="submit"
                        disabled={candidateMutation.isPending}
                        className="flex-1"
                        data-testid="button-submit"
                      >
                        {candidateMutation.isPending ? "Saving..." : "Save Profile"}
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => navigate("/dashboard")}
                        data-testid="button-cancel"
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                </Form>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}
