import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Briefcase, UserCircle } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function UserTypeSelection() {
  const { toast } = useToast();

  const setupMutation = useMutation({
    mutationFn: async (userType: "candidate" | "employer") => {
      await apiRequest("/api/auth/setup", "POST", { userType });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Success",
        description: "Account setup complete!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-2" data-testid="text-welcome">
            Welcome to MGJobPlatform
          </h1>
          <p className="text-lg text-muted-foreground" data-testid="text-description">
            Let's set up your account. Are you here to find a job or hire talent?
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Card className="hover-elevate cursor-pointer" onClick={() => setupMutation.mutate("candidate")} data-testid="card-candidate">
            <CardHeader className="text-center pb-4">
              <div className="mx-auto w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <UserCircle className="h-10 w-10 text-primary" />
              </div>
              <CardTitle className="text-2xl">I'm a Job Seeker</CardTitle>
              <CardDescription>Find your dream job and advance your career</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• Browse thousands of job opportunities</li>
                <li>• Apply to jobs with one click</li>
                <li>• Track your applications</li>
                <li>• Create and showcase your profile</li>
              </ul>
              <Button 
                className="w-full mt-6" 
                disabled={setupMutation.isPending}
                data-testid="button-candidate"
              >
                {setupMutation.isPending ? "Setting up..." : "Continue as Candidate"}
              </Button>
            </CardContent>
          </Card>

          <Card className="hover-elevate cursor-pointer" onClick={() => setupMutation.mutate("employer")} data-testid="card-employer">
            <CardHeader className="text-center pb-4">
              <div className="mx-auto w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Briefcase className="h-10 w-10 text-primary" />
              </div>
              <CardTitle className="text-2xl">I'm an Employer</CardTitle>
              <CardDescription>Find talented professionals to join your team</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• Post unlimited job openings</li>
                <li>• Manage applications efficiently</li>
                <li>• Access a pool of qualified candidates</li>
                <li>• Build your company profile</li>
              </ul>
              <Button 
                className="w-full mt-6" 
                disabled={setupMutation.isPending}
                data-testid="button-employer"
              >
                {setupMutation.isPending ? "Setting up..." : "Continue as Employer"}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
