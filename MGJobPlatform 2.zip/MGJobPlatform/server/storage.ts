import {
  users,
  employerProfiles,
  candidateProfiles,
  jobs,
  applications,
  type User,
  type UpsertUser,
  type EmployerProfile,
  type InsertEmployerProfile,
  type CandidateProfile,
  type InsertCandidateProfile,
  type Job,
  type InsertJob,
  type Application,
  type InsertApplication,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserType(id: string, userType: "candidate" | "employer"): Promise<User>;
  
  // Employer profile operations
  getEmployerProfile(userId: string): Promise<EmployerProfile | undefined>;
  createEmployerProfile(profile: InsertEmployerProfile): Promise<EmployerProfile>;
  updateEmployerProfile(userId: string, profile: Partial<InsertEmployerProfile>): Promise<EmployerProfile>;
  
  // Candidate profile operations
  getCandidateProfile(userId: string): Promise<CandidateProfile | undefined>;
  createCandidateProfile(profile: InsertCandidateProfile): Promise<CandidateProfile>;
  updateCandidateProfile(userId: string, profile: Partial<InsertCandidateProfile>): Promise<CandidateProfile>;
  
  // Job operations
  getJob(id: string): Promise<Job | undefined>;
  getAllJobs(filters?: { status?: string; jobType?: string; location?: string }): Promise<Job[]>;
  getJobsByEmployer(employerId: string): Promise<Job[]>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: string, job: Partial<InsertJob>): Promise<Job>;
  deleteJob(id: string): Promise<void>;
  
  // Application operations
  getApplication(id: string): Promise<Application | undefined>;
  getApplicationsByJob(jobId: string): Promise<Application[]>;
  getApplicationsByCandidate(candidateId: string): Promise<Application[]>;
  createApplication(application: InsertApplication): Promise<Application>;
  updateApplicationStatus(id: string, status: string): Promise<Application>;
  checkExistingApplication(jobId: string, candidateId: string): Promise<Application | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserType(id: string, userType: "candidate" | "employer"): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ userType, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Employer profile operations
  async getEmployerProfile(userId: string): Promise<EmployerProfile | undefined> {
    const [profile] = await db
      .select()
      .from(employerProfiles)
      .where(eq(employerProfiles.userId, userId));
    return profile;
  }

  async createEmployerProfile(profileData: InsertEmployerProfile): Promise<EmployerProfile> {
    const [profile] = await db
      .insert(employerProfiles)
      .values(profileData)
      .returning();
    return profile;
  }

  async updateEmployerProfile(userId: string, profileData: Partial<InsertEmployerProfile>): Promise<EmployerProfile> {
    const [profile] = await db
      .update(employerProfiles)
      .set({ ...profileData, updatedAt: new Date() })
      .where(eq(employerProfiles.userId, userId))
      .returning();
    return profile;
  }

  // Candidate profile operations
  async getCandidateProfile(userId: string): Promise<CandidateProfile | undefined> {
    const [profile] = await db
      .select()
      .from(candidateProfiles)
      .where(eq(candidateProfiles.userId, userId));
    return profile;
  }

  async createCandidateProfile(profileData: InsertCandidateProfile): Promise<CandidateProfile> {
    const [profile] = await db
      .insert(candidateProfiles)
      .values(profileData)
      .returning();
    return profile;
  }

  async updateCandidateProfile(userId: string, profileData: Partial<InsertCandidateProfile>): Promise<CandidateProfile> {
    const [profile] = await db
      .update(candidateProfiles)
      .set({ ...profileData, updatedAt: new Date() })
      .where(eq(candidateProfiles.userId, userId))
      .returning();
    return profile;
  }

  // Job operations
  async getJob(id: string): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job;
  }

  async getAllJobs(filters?: { status?: string; jobType?: string; location?: string }): Promise<Job[]> {
    let query = db.select().from(jobs);
    
    if (filters) {
      const conditions = [];
      if (filters.status) {
        conditions.push(sql`${jobs.status} = ${filters.status}`);
      }
      if (filters.jobType) {
        conditions.push(sql`${jobs.jobType} = ${filters.jobType}`);
      }
      if (filters.location) {
        conditions.push(sql`${jobs.location} ILIKE ${`%${filters.location}%`}`);
      }
      
      if (conditions.length > 0) {
        query = query.where(and(...conditions)) as any;
      }
    }
    
    return await query.orderBy(desc(jobs.createdAt));
  }

  async getJobsByEmployer(employerId: string): Promise<Job[]> {
    return await db
      .select()
      .from(jobs)
      .where(eq(jobs.employerId, employerId))
      .orderBy(desc(jobs.createdAt));
  }

  async createJob(jobData: InsertJob): Promise<Job> {
    const [job] = await db.insert(jobs).values(jobData).returning();
    return job;
  }

  async updateJob(id: string, jobData: Partial<InsertJob>): Promise<Job> {
    const [job] = await db
      .update(jobs)
      .set({ ...jobData, updatedAt: new Date() })
      .where(eq(jobs.id, id))
      .returning();
    return job;
  }

  async deleteJob(id: string): Promise<void> {
    await db.delete(jobs).where(eq(jobs.id, id));
  }

  // Application operations
  async getApplication(id: string): Promise<Application | undefined> {
    const [application] = await db
      .select()
      .from(applications)
      .where(eq(applications.id, id));
    return application;
  }

  async getApplicationsByJob(jobId: string): Promise<Application[]> {
    return await db
      .select()
      .from(applications)
      .where(eq(applications.jobId, jobId))
      .orderBy(desc(applications.createdAt));
  }

  async getApplicationsByCandidate(candidateId: string): Promise<Application[]> {
    return await db
      .select()
      .from(applications)
      .where(eq(applications.candidateId, candidateId))
      .orderBy(desc(applications.createdAt));
  }

  async createApplication(applicationData: InsertApplication): Promise<Application> {
    const [application] = await db
      .insert(applications)
      .values(applicationData)
      .returning();
    return application;
  }

  async updateApplicationStatus(id: string, status: string): Promise<Application> {
    const [application] = await db
      .update(applications)
      .set({ status: status as any, updatedAt: new Date() })
      .where(eq(applications.id, id))
      .returning();
    return application;
  }

  async checkExistingApplication(jobId: string, candidateId: string): Promise<Application | undefined> {
    const [application] = await db
      .select()
      .from(applications)
      .where(and(
        eq(applications.jobId, jobId),
        eq(applications.candidateId, candidateId)
      ));
    return application;
  }
}

export const storage = new DatabaseStorage();
