import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertJobSchema, insertApplicationSchema, insertEmployerProfileSchema, insertCandidateProfileSchema } from "@shared/schema";
import { fromError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware setup
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Also fetch profile data based on user type
      let profile = null;
      if (user.userType === "employer") {
        profile = await storage.getEmployerProfile(userId);
      } else if (user.userType === "candidate") {
        profile = await storage.getCandidateProfile(userId);
      }
      
      res.json({ ...user, profile });
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.post('/api/auth/setup', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { userType } = req.body;
      
      if (!userType || !["candidate", "employer"].includes(userType)) {
        return res.status(400).json({ message: "Invalid user type" });
      }
      
      await storage.updateUserType(userId, userType);
      res.json({ success: true });
    } catch (error) {
      console.error("Error setting up user:", error);
      res.status(500).json({ message: "Failed to setup user" });
    }
  });

  // Employer profile routes
  app.post('/api/employer/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.userType !== "employer") {
        return res.status(403).json({ message: "Not authorized as employer" });
      }
      
      const result = insertEmployerProfileSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: fromError(result.error).toString() });
      }
      
      const profile = await storage.createEmployerProfile({
        ...result.data,
        userId
      });
      res.json(profile);
    } catch (error) {
      console.error("Error creating employer profile:", error);
      res.status(500).json({ message: "Failed to create profile" });
    }
  });

  app.put('/api/employer/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.updateEmployerProfile(userId, req.body);
      res.json(profile);
    } catch (error) {
      console.error("Error updating employer profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Candidate profile routes
  app.post('/api/candidate/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.userType !== "candidate") {
        return res.status(403).json({ message: "Not authorized as candidate" });
      }
      
      const result = insertCandidateProfileSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: fromError(result.error).toString() });
      }
      
      const profile = await storage.createCandidateProfile({
        ...result.data,
        userId
      });
      res.json(profile);
    } catch (error) {
      console.error("Error creating candidate profile:", error);
      res.status(500).json({ message: "Failed to create profile" });
    }
  });

  app.put('/api/candidate/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.updateCandidateProfile(userId, req.body);
      res.json(profile);
    } catch (error) {
      console.error("Error updating candidate profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Job routes
  app.get('/api/jobs', async (req, res) => {
    try {
      const { status, jobType, location } = req.query;
      const jobs = await storage.getAllJobs({
        status: status as string,
        jobType: jobType as string,
        location: location as string,
      });
      res.json(jobs);
    } catch (error) {
      console.error("Error fetching jobs:", error);
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  app.get('/api/jobs/:id', async (req, res) => {
    try {
      const job = await storage.getJob(req.params.id);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      // Get employer info
      const employer = await storage.getUser(job.employerId);
      const employerProfile = await storage.getEmployerProfile(job.employerId);
      
      res.json({ ...job, employer, employerProfile });
    } catch (error) {
      console.error("Error fetching job:", error);
      res.status(500).json({ message: "Failed to fetch job" });
    }
  });

  app.get('/api/employer/jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const jobs = await storage.getJobsByEmployer(userId);
      res.json(jobs);
    } catch (error) {
      console.error("Error fetching employer jobs:", error);
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  app.post('/api/jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.userType !== "employer") {
        return res.status(403).json({ message: "Only employers can post jobs" });
      }
      
      const result = insertJobSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: fromError(result.error).toString() });
      }
      
      const job = await storage.createJob({
        ...result.data,
        employerId: userId
      });
      res.json(job);
    } catch (error) {
      console.error("Error creating job:", error);
      res.status(500).json({ message: "Failed to create job" });
    }
  });

  app.put('/api/jobs/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const job = await storage.getJob(req.params.id);
      
      if (!job || job.employerId !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const updatedJob = await storage.updateJob(req.params.id, req.body);
      res.json(updatedJob);
    } catch (error) {
      console.error("Error updating job:", error);
      res.status(500).json({ message: "Failed to update job" });
    }
  });

  app.delete('/api/jobs/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const job = await storage.getJob(req.params.id);
      
      if (!job || job.employerId !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      await storage.deleteJob(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting job:", error);
      res.status(500).json({ message: "Failed to delete job" });
    }
  });

  // Application routes
  app.get('/api/applications/candidate', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const applications = await storage.getApplicationsByCandidate(userId);
      
      // Enrich with job details
      const enriched = await Promise.all(
        applications.map(async (app) => {
          const job = await storage.getJob(app.jobId);
          const employer = job ? await storage.getUser(job.employerId) : null;
          const employerProfile = job ? await storage.getEmployerProfile(job.employerId) : null;
          return { ...app, job, employer, employerProfile };
        })
      );
      
      res.json(enriched);
    } catch (error) {
      console.error("Error fetching candidate applications:", error);
      res.status(500).json({ message: "Failed to fetch applications" });
    }
  });

  app.get('/api/applications/job/:jobId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const job = await storage.getJob(req.params.jobId);
      
      if (!job || job.employerId !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const applications = await storage.getApplicationsByJob(req.params.jobId);
      
      // Enrich with candidate details
      const enriched = await Promise.all(
        applications.map(async (app) => {
          const candidate = await storage.getUser(app.candidateId);
          const candidateProfile = await storage.getCandidateProfile(app.candidateId);
          return { ...app, candidate, candidateProfile };
        })
      );
      
      res.json(enriched);
    } catch (error) {
      console.error("Error fetching job applications:", error);
      res.status(500).json({ message: "Failed to fetch applications" });
    }
  });

  app.post('/api/applications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.userType !== "candidate") {
        return res.status(403).json({ message: "Only candidates can apply" });
      }
      
      // Check if already applied
      const existing = await storage.checkExistingApplication(req.body.jobId, userId);
      if (existing) {
        return res.status(400).json({ message: "Already applied to this job" });
      }
      
      const result = insertApplicationSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: fromError(result.error).toString() });
      }
      
      const application = await storage.createApplication({
        ...result.data,
        candidateId: userId
      });
      res.json(application);
    } catch (error) {
      console.error("Error creating application:", error);
      res.status(500).json({ message: "Failed to create application" });
    }
  });

  app.put('/api/applications/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const application = await storage.getApplication(req.params.id);
      
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      const job = await storage.getJob(application.jobId);
      if (!job || job.employerId !== userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const { status } = req.body;
      const updated = await storage.updateApplicationStatus(req.params.id, status);
      res.json(updated);
    } catch (error) {
      console.error("Error updating application status:", error);
      res.status(500).json({ message: "Failed to update application" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
